﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace NightOwlClock25.App;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
    protected override void OnExit(ExitEventArgs e)
    {
        ExitLog.Write("[Exit] Application exit started");
        base.OnExit(e);
        ExitLog.Write("[Exit] Application exit completed");
    }
}

