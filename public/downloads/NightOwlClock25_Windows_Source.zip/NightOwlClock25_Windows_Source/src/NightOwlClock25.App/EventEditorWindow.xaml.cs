using System.Windows;
using System.Windows.Controls;
using NightOwlClock25.Core;

namespace NightOwlClock25.App;

public partial class EventEditorWindow : Window
{
    private readonly AppEvent? _existing;
    private readonly LogicalDateTimeConverter _converter = new();
    public AppEvent? Result { get; private set; }

    public EventEditorWindow(AppEvent? existing)
    {
        InitializeComponent(); _existing = existing;
        StartHour.ItemsSource = EndHour.ItemsSource = Enumerable.Range(0, 36);
        StartMinute.ItemsSource = EndMinute.ItemsSource = Enumerable.Range(0, 60);
        Heading.Text = existing is null ? "予定を追加" : "予定を編集";
        if (existing is null)
        {
            var today = DateTime.Today; StartDate.SelectedDate = EndDate.SelectedDate = today;
            StartHour.SelectedItem = 20; EndHour.SelectedItem = 21; StartMinute.SelectedItem = EndMinute.SelectedItem = 0;
        }
        else Populate(existing);
    }

    private void Populate(AppEvent value)
    {
        TitleInput.Text = value.Title; NotesInput.Text = value.Notes;
        StartDate.SelectedDate = new DateTime(value.Start.LogicalDate.Year, value.Start.LogicalDate.Month, value.Start.LogicalDate.Day);
        EndDate.SelectedDate = new DateTime(value.End.LogicalDate.Year, value.End.LogicalDate.Month, value.End.LogicalDate.Day);
        StartHour.SelectedItem = value.Start.Hour; StartMinute.SelectedItem = value.Start.Minute;
        EndHour.SelectedItem = value.End.Hour; EndMinute.SelectedItem = value.End.Minute;
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var title = TitleInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(title)) throw new InvalidOperationException("タイトルを入力してください。");
            var start = Read(StartDate, StartHour, StartMinute); var end = Read(EndDate, EndHour, EndMinute);
            if (_converter.ToActual(start) >= _converter.ToActual(end)) throw new InvalidOperationException("終了日時は開始日時より後にしてください。");
            Result = new AppEvent(_existing?.Id ?? Guid.NewGuid(), title, start, end, NotesInput.Text.Trim());
            DialogResult = true;
        }
        catch (Exception ex) { ValidationText.Text = ex.Message; }
    }

    private static LogicalDateTime Read(DatePicker datePicker, System.Windows.Controls.ComboBox hour, System.Windows.Controls.ComboBox minute)
    {
        var date = datePicker.SelectedDate ?? throw new InvalidOperationException("日付を選択してください。");
        return new(new LogicalDate(date.Year, date.Month, date.Day), (int)hour.SelectedItem, (int)minute.SelectedItem);
    }
}
