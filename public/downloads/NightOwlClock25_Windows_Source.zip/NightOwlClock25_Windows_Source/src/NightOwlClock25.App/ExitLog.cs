using System.Diagnostics;
using System.IO;

namespace NightOwlClock25.App;

internal static class ExitLog
{
    private static readonly string Path = System.IO.Path.Combine(
        Environment.GetEnvironmentVariable("NIGHTOWL_DATA_DIR")
            ?? System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NightOwlClock25"),
        "exit.log");

    public static void Write(string message)
    {
        var line = $"{DateTimeOffset.Now:O} {message}";
        Debug.WriteLine(line);
        try
        {
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Path)!);
            File.AppendAllText(Path, line + Environment.NewLine);
        }
        catch
        {
            // 終了診断ログの失敗でアプリの終了を妨げない。
        }
    }
}
