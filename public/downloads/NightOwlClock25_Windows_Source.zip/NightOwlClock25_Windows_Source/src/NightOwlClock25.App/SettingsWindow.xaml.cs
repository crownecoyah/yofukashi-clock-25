using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NightOwlClock25.Core;

namespace NightOwlClock25.App;

public partial class SettingsWindow : Window
{
    private readonly AppSettings _settings;
    private readonly Action<string, double> _previewChanged;
    private readonly IReadOnlyList<FontChoice> _fonts;
    private bool _initializing = true;

    public SettingsWindow(AppSettings settings, Action<string, double> previewChanged)
    {
        InitializeComponent(); _settings = settings; _previewChanged = previewChanged;
        BoundaryInput.ItemsSource = Enumerable.Range(0, 13).Select(x => new { Value = x, Label = $"{x}時まで今日" });
        BoundaryInput.SelectedValue = settings.BoundaryHour; SecondsInput.IsChecked = settings.ShowsSeconds;
        TopmostInput.IsChecked = settings.AlwaysOnTop; LoginInput.IsChecked = settings.LaunchAtLogin;

        var defaultChoice = new FontChoice(AppSettings.DefaultDigitalClockFontFamily, "既定", new FontFamily(AppSettings.DefaultDigitalClockFontFamily));
        _fonts = new[] { defaultChoice }.Concat(Fonts.SystemFontFamilies
            .OrderBy(font => font.Source, StringComparer.CurrentCultureIgnoreCase)
            .Select(font => new FontChoice(font.Source, font.Source, font))).ToList();
        FontInput.ItemsSource = _fonts;
        FontInput.SelectedItem = _fonts.FirstOrDefault(choice => string.Equals(choice.Key, settings.DigitalClockFontFamily, StringComparison.CurrentCultureIgnoreCase)) ?? defaultChoice;
        FontSizeInput.Value = double.IsFinite(settings.DigitalClockFontSize) ? Math.Clamp(settings.DigitalClockFontSize, 40, 100) : AppSettings.DefaultDigitalClockFontSize;
        _initializing = false; UpdatePreview();
    }

    private void FontInput_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (!_initializing) UpdatePreview(); }
    private void FontSizeInput_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) { if (!_initializing) UpdatePreview(); }

    private void ResetClockStyle_Click(object sender, RoutedEventArgs e)
    {
        FontInput.SelectedIndex = 0; FontSizeInput.Value = AppSettings.DefaultDigitalClockFontSize; UpdatePreview();
    }

    private void UpdatePreview()
    {
        if (FontInput.SelectedItem is not FontChoice choice) return;
        FontSizeValue.Text = $"{FontSizeInput.Value:0} pt";
        FontPreview.FontFamily = choice.PreviewFont; FontPreview.FontSize = FontSizeInput.Value;
        _previewChanged(choice.Key, FontSizeInput.Value);
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        _settings.BoundaryHour = (int)BoundaryInput.SelectedValue; _settings.ShowsSeconds = SecondsInput.IsChecked == true;
        _settings.AlwaysOnTop = TopmostInput.IsChecked == true; _settings.LaunchAtLogin = LoginInput.IsChecked == true;
        var choice = (FontChoice)FontInput.SelectedItem; _settings.DigitalClockFontFamily = choice.Key; _settings.DigitalClockFontSize = FontSizeInput.Value;
        DialogResult = true;
    }

    private sealed record FontChoice(string Key, string DisplayName, FontFamily PreviewFont);
}
