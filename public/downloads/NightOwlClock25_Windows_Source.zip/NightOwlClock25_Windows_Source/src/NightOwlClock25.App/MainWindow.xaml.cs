using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;
using NightOwlClock25.Core;

namespace NightOwlClock25.App;

public partial class MainWindow : Window
{
    private readonly DispatcherTimer _timer = new();
    private readonly LogicalDateTimeConverter _converter = new();
    private readonly JsonFileStore _store = new();
    private readonly ObservableCollection<EventRow> _eventRows = [];
    private List<AppEvent> _events = [];
    private AppSettings _settings = new();
    private bool _ready;

    public MainWindow()
    {
        InitializeComponent(); EventsList.ItemsSource = _eventRows;
        Loaded += MainWindow_Loaded; Closing += MainWindow_Closing; Closed += MainWindow_Closed;
        _timer.Tick += (_, _) => UpdateClock();
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try { _settings = await _store.LoadSettingsAsync(); _events = (await _store.LoadEventsAsync()).ToList(); }
        catch (Exception ex) { MessageBox.Show(this, $"保存データを読み込めませんでした。\n{ex.Message}", "夜ふかし時計25時", MessageBoxButton.OK, MessageBoxImage.Warning); }
        RestoreWindow(); ApplySettings(); RefreshEvents(); UpdateClock(); _ready = true;
    }

    private void ApplySettings()
    {
        _settings.NormalizeDisplayValues();
        Topmost = _settings.AlwaysOnTop; Clock.ShowsSeconds = _settings.ShowsSeconds;
        ApplyDigitalClockAppearance(_settings.DigitalClockFontFamily, _settings.DigitalClockFontSize);
        _timer.Interval = _settings.ShowsSeconds ? TimeSpan.FromMilliseconds(250) : TimeSpan.FromSeconds(1); _timer.Start();
    }

    private void UpdateClock()
    {
        var now = DateTimeOffset.Now; Clock.Time = now;
        var logical = _converter.FromActual(now, _settings.BoundaryHour);
        DateText.Text = $"{logical.LogicalDate.Year:0000}年{logical.LogicalDate.Month:00}月{logical.LogicalDate.Day:00}日";
        TimeText.Text = _settings.ShowsSeconds ? $"{logical.Hour:00}:{logical.Minute:00}:{logical.Second:00}" : $"{logical.Hour:00}:{logical.Minute:00}";
    }

    private void RefreshEvents()
    {
        _events = _events.OrderBy(x => _converter.ToActual(x.Start)).ToList();
        _eventRows.Clear(); foreach (var item in _events) _eventRows.Add(new(item));
        EmptyText.Visibility = _events.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private void AddEvent_Click(object sender, RoutedEventArgs e) => EditEvent(null);
    private void EditEvent_Click(object sender, RoutedEventArgs e) => EditEvent(((FrameworkElement)sender).Tag is EventRow row ? row.Event : null);
    private async void EditEvent(AppEvent? existing)
    {
        var editor = new EventEditorWindow(existing) { Owner = this };
        if (editor.ShowDialog() != true || editor.Result is null) return;
        var index = _events.FindIndex(x => x.Id == editor.Result.Id); if (index >= 0) _events[index] = editor.Result; else _events.Add(editor.Result);
        await SaveEventsAsync(); RefreshEvents();
    }

    private async void DeleteEvent_Click(object sender, RoutedEventArgs e)
    {
        if (((FrameworkElement)sender).Tag is not EventRow row) return;
        if (MessageBox.Show(this, $"「{row.Event.Title}」を削除しますか？", "予定の削除", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        _events.RemoveAll(x => x.Id == row.Event.Id); await SaveEventsAsync(); RefreshEvents();
    }

    private async Task SaveEventsAsync()
    {
        try { await _store.SaveEventsAsync(_events); }
        catch (Exception ex) { MessageBox.Show(this, $"予定を保存できませんでした。\n{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void Settings_Click(object sender, RoutedEventArgs e)
    {
        var oldLogin = _settings.LaunchAtLogin;
        var dialog = new SettingsWindow(_settings, ApplyDigitalClockAppearance) { Owner = this };
        if (dialog.ShowDialog() != true) { ApplyDigitalClockAppearance(_settings.DigitalClockFontFamily, _settings.DigitalClockFontSize); return; }
        try { if (oldLogin != _settings.LaunchAtLogin) StartupManager.SetEnabled(_settings.LaunchAtLogin); CaptureWindowPlacement(); ApplySettings(); await _store.SaveSettingsAsync(_settings); UpdateClock(); }
        catch (Exception ex) { _settings.LaunchAtLogin = oldLogin; MessageBox.Show(this, $"設定を保存できませんでした。\n{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void ApplyDigitalClockAppearance(string fontFamily, double fontSize)
    {
        var installed = Fonts.SystemFontFamilies.FirstOrDefault(font => string.Equals(font.Source, fontFamily, StringComparison.CurrentCultureIgnoreCase));
        if (installed is null && !string.Equals(fontFamily, AppSettings.DefaultDigitalClockFontFamily, StringComparison.Ordinal))
            _settings.DigitalClockFontFamily = AppSettings.DefaultDigitalClockFontFamily;
        TimeText.FontFamily = installed ?? new FontFamily(AppSettings.DefaultDigitalClockFontFamily);
        TimeText.FontSize = double.IsFinite(fontSize) && fontSize is >= AppSettings.MinimumDigitalClockFontSize and <= AppSettings.MaximumDigitalClockFontSize
            ? fontSize : AppSettings.DefaultDigitalClockFontSize;
    }

    private void RestoreWindow()
    {
        _settings.NormalizeWindowValues();
        if (_settings.WindowWidth >= MinWidth) Width = _settings.WindowWidth; if (_settings.WindowHeight >= MinHeight) Height = _settings.WindowHeight;
        if (_settings.HasWindowPlacement && double.IsFinite(_settings.WindowLeft) && double.IsFinite(_settings.WindowTop))
        {
            var area = SystemParameters.VirtualScreenWidth > 0;
            if (area && _settings.WindowLeft + 80 >= SystemParameters.VirtualScreenLeft && _settings.WindowLeft < SystemParameters.VirtualScreenLeft + SystemParameters.VirtualScreenWidth && _settings.WindowTop + 40 >= SystemParameters.VirtualScreenTop && _settings.WindowTop < SystemParameters.VirtualScreenTop + SystemParameters.VirtualScreenHeight)
            { WindowStartupLocation = WindowStartupLocation.Manual; Left = _settings.WindowLeft; Top = _settings.WindowTop; }
        }
        if (_settings.IsMaximized) WindowState = WindowState.Maximized;
    }

    private void MainWindow_Closing(object? sender, CancelEventArgs e)
    {
        ExitLog.Write("[Exit] Closing started");
        ExitLog.Write("[Exit] Stopping clock timer");
        _timer.Stop();
        if (!_ready)
        {
            ExitLog.Write("[Exit] Closing completed (startup was not complete)");
            return;
        }

        try
        {
            CaptureWindowPlacement();
            ExitLog.Write("[Exit] Saving settings");
            _store.SaveSettings(_settings);
            ExitLog.Write("[Exit] Settings saved");
        }
        catch (Exception exception)
        {
            ExitLog.Write($"[Exit] Settings save failed: {exception.GetType().Name}: {exception.Message}");
        }
        ExitLog.Write("[Exit] Closing completed");
    }

    private static void MainWindow_Closed(object? sender, EventArgs e) => ExitLog.Write("[Exit] Window closed");

    private void CaptureWindowPlacement()
    {
        var bounds = RestoreBounds;
        _settings.WindowLeft = FirstFinite(bounds.Left, Left, AppSettings.DefaultWindowLeft);
        _settings.WindowTop = FirstFinite(bounds.Top, Top, AppSettings.DefaultWindowTop);
        _settings.WindowWidth = FirstPositiveFinite(bounds.Width, Width, ActualWidth, AppSettings.DefaultWindowWidth);
        _settings.WindowHeight = FirstPositiveFinite(bounds.Height, Height, ActualHeight, AppSettings.DefaultWindowHeight);
        _settings.IsMaximized = WindowState == WindowState.Maximized;
        _settings.HasWindowPlacement = true;
        _settings.NormalizeWindowValues();
    }

    private static double FirstFinite(params double[] values) => values.First(double.IsFinite);
    private static double FirstPositiveFinite(params double[] values) => values.First(value => double.IsFinite(value) && value > 0);

    public sealed record EventRow(AppEvent Event)
    {
        public string Title => Event.Title; public string Notes => Event.Notes;
        public string ScheduleText => $"{Format(Event.Start)}  →  {Format(Event.End)}";
        private static string Format(LogicalDateTime value) => $"{value.LogicalDate.Year:0000}/{value.LogicalDate.Month:00}/{value.LogicalDate.Day:00} {value.Hour:00}:{value.Minute:00}";
    }
}
