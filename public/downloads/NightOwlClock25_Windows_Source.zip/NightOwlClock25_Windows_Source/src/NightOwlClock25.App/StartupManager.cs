using Microsoft.Win32;

namespace NightOwlClock25.App;

internal static class StartupManager
{
    private const string KeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "NightOwlClock25";
    public static void SetEnabled(bool enabled)
    {
        using var key = Registry.CurrentUser.OpenSubKey(KeyPath, writable: true) ?? throw new InvalidOperationException("Windowsの自動起動設定を開けません。");
        if (enabled)
        {
            var executable = Environment.ProcessPath ?? throw new InvalidOperationException("アプリの実行ファイルを特定できません。");
            key.SetValue(ValueName, $"\"{executable}\"");
        }
        else key.DeleteValue(ValueName, throwOnMissingValue: false);
    }
}
