using System.Windows;
using System.Windows.Media;

namespace NightOwlClock25.App;

public sealed class AnalogClock : FrameworkElement
{
    public static readonly DependencyProperty TimeProperty = DependencyProperty.Register(nameof(Time), typeof(DateTimeOffset), typeof(AnalogClock), new FrameworkPropertyMetadata(DateTimeOffset.Now, FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty ShowsSecondsProperty = DependencyProperty.Register(nameof(ShowsSeconds), typeof(bool), typeof(AnalogClock), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));
    public DateTimeOffset Time { get => (DateTimeOffset)GetValue(TimeProperty); set => SetValue(TimeProperty, value); }
    public bool ShowsSeconds { get => (bool)GetValue(ShowsSecondsProperty); set => SetValue(ShowsSecondsProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var size = Math.Min(ActualWidth, ActualHeight);
        var center = new Point(ActualWidth / 2, ActualHeight / 2);
        var radius = Math.Max(0, size / 2 - 3);
        dc.DrawEllipse(SystemColors.ControlLightLightBrush, new Pen(new SolidColorBrush(Color.FromRgb(190, 197, 210)), 2), center, radius, radius);
        for (var i = 0; i < 60; i++)
        {
            var major = i % 5 == 0;
            DrawLine(dc, center, radius * (major ? .86 : .91), radius * .95, i * 6, new Pen(SystemColors.ControlTextBrush, major ? 2 : 1));
        }
        for (var n = 1; n <= 12; n++)
        {
            var p = PointAt(center, radius * .72, n * 30);
            var text = new FormattedText(n.ToString(), System.Globalization.CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                new Typeface("Segoe UI Variable Text"), Math.Max(11, radius * .11), SystemColors.ControlTextBrush, VisualTreeHelper.GetDpi(this).PixelsPerDip);
            dc.DrawText(text, new Point(p.X - text.Width / 2, p.Y - text.Height / 2));
        }
        var local = Time.LocalDateTime;
        var second = local.Second + local.Millisecond / 1000d;
        var minute = local.Minute + second / 60;
        var hour = local.Hour % 12 + minute / 60;
        DrawHand(dc, center, radius * .5, hour / 12 * 360, Math.Max(4, size * .025), SystemColors.ControlTextBrush);
        DrawHand(dc, center, radius * .72, minute / 60 * 360, Math.Max(2.5, size * .016), SystemColors.ControlTextBrush);
        if (ShowsSeconds) DrawHand(dc, center, radius * .8, second / 60 * 360, Math.Max(1, size * .006), Brushes.IndianRed);
        dc.DrawEllipse(SystemColors.ControlTextBrush, null, center, 4, 4);
    }

    private static Point PointAt(Point c, double r, double degrees) { var a = (degrees - 90) * Math.PI / 180; return new(c.X + r * Math.Cos(a), c.Y + r * Math.Sin(a)); }
    private static void DrawLine(DrawingContext dc, Point c, double from, double to, double degrees, Pen pen) => dc.DrawLine(pen, PointAt(c, from, degrees), PointAt(c, to, degrees));
    private static void DrawHand(DrawingContext dc, Point c, double length, double degrees, double width, Brush brush) { var pen = new Pen(brush, width) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }; dc.DrawLine(pen, PointAt(c, -length * .12, degrees), PointAt(c, length, degrees)); }
}
