namespace NightOwlClock25.Core;

public sealed record AppEvent(Guid Id, string Title, LogicalDateTime Start, LogicalDateTime End, string Notes = "")
{
    public static AppEvent Create(string title, LogicalDateTime start, LogicalDateTime end, string notes = "") => new(Guid.NewGuid(), title, start, end, notes);
}
