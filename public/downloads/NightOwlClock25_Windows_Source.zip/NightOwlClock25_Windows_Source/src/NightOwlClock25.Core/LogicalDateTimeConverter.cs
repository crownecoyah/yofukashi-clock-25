namespace NightOwlClock25.Core;

/// <summary>生活日付＋0〜35時表記と実日時を相互変換します。UIには依存しません。</summary>
public sealed class LogicalDateTimeConverter
{
    public TimeZoneInfo TimeZone { get; }
    public LogicalDateTimeConverter(TimeZoneInfo? timeZone = null) => TimeZone = timeZone ?? TimeZoneInfo.Local;

    public DateTimeOffset ToActual(LogicalDateTime logical)
    {
        var logicalDate = logical.LogicalDate.ToDateOnly();
        var actualDate = logicalDate.AddDays(logical.Hour / 24);
        var local = new DateTime(actualDate.Year, actualDate.Month, actualDate.Day, logical.Hour % 24, logical.Minute, logical.Second, DateTimeKind.Unspecified);
        if (TimeZone.IsInvalidTime(local)) throw new LogicalDateTimeException("指定された現地時刻は夏時間の切り替えにより存在しません。");
        var offset = TimeZone.IsAmbiguousTime(local) ? TimeZone.GetAmbiguousTimeOffsets(local).Min() : TimeZone.GetUtcOffset(local);
        return new DateTimeOffset(local, offset);
    }

    public LogicalDateTime FromActual(DateTimeOffset actual, int boundaryHour)
    {
        if (boundaryHour is < 0 or > 12) throw new ArgumentOutOfRangeException(nameof(boundaryHour), "一日の境界は0〜12時で指定してください。");
        var local = TimeZoneInfo.ConvertTime(actual, TimeZone);
        var date = DateOnly.FromDateTime(local.DateTime);
        var hour = local.Hour;
        if (hour < boundaryHour) { date = date.AddDays(-1); hour += 24; }
        return new LogicalDateTime(LogicalDate.FromDateOnly(date), hour, local.Minute, local.Second);
    }
}
