namespace NightOwlClock25.Core;

public sealed record LogicalDateTime
{
    public const int MinimumHour = 0;
    public const int MaximumHour = 35;
    public LogicalDate LogicalDate { get; init; }
    public int Hour { get; init; }
    public int Minute { get; init; }
    public int Second { get; init; }

    public LogicalDateTime(LogicalDate logicalDate, int hour, int minute, int second = 0)
    {
        if (hour is < MinimumHour or > MaximumHour) throw new ArgumentOutOfRangeException(nameof(hour), "時は0〜35の範囲で指定してください。");
        if (minute is < 0 or > 59) throw new ArgumentOutOfRangeException(nameof(minute), "分は0〜59の範囲で指定してください。");
        if (second is < 0 or > 59) throw new ArgumentOutOfRangeException(nameof(second), "秒は0〜59の範囲で指定してください。");
        LogicalDate = logicalDate; Hour = hour; Minute = minute; Second = second;
    }

    public override string ToString() => $"{LogicalDate.Year:0000}/{LogicalDate.Month:00}/{LogicalDate.Day:00} {Hour:00}:{Minute:00}:{Second:00}";
}
