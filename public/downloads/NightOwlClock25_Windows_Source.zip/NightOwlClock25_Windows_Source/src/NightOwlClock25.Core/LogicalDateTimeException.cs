namespace NightOwlClock25.Core;

public sealed class LogicalDateTimeException : Exception
{
    public LogicalDateTimeException(string message) : base(message) { }
    public LogicalDateTimeException(string message, Exception innerException) : base(message, innerException) { }
}
