using System.Text.Json;
using System.Text.Json.Serialization;

namespace NightOwlClock25.Core;

public sealed class JsonFileStore
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };
    public string DirectoryPath { get; }
    public string EventsPath => Path.Combine(DirectoryPath, "events.json");
    public string SettingsPath => Path.Combine(DirectoryPath, "settings.json");

    public JsonFileStore(string? directoryPath = null)
    {
        DirectoryPath = directoryPath
            ?? Environment.GetEnvironmentVariable("NIGHTOWL_DATA_DIR")
            ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NightOwlClock25");
    }

    public Task<IReadOnlyList<AppEvent>> LoadEventsAsync() => LoadAsync<IReadOnlyList<AppEvent>>(EventsPath, []);
    public Task SaveEventsAsync(IEnumerable<AppEvent> events) => SaveAsync(EventsPath, events.OrderBy(e => e.Start.ToString()).ToList());
    public Task<AppSettings> LoadSettingsAsync() => LoadAsync(SettingsPath, new AppSettings());
    public void SaveSettings(AppSettings settings)
    {
        settings.NormalizeWindowValues();
        settings.NormalizeDisplayValues();
        settings.BoundaryHour = Math.Clamp(settings.BoundaryHour, 0, 12);
        Save(SettingsPath, settings);
    }

    public Task SaveSettingsAsync(AppSettings settings)
    {
        SaveSettings(settings);
        return Task.CompletedTask;
    }

    private static async Task<T> LoadAsync<T>(string path, T defaultValue)
    {
        if (!File.Exists(path)) return defaultValue;
        await using var stream = File.OpenRead(path);
        return await JsonSerializer.DeserializeAsync<T>(stream, Options) ?? defaultValue;
    }

    private async Task SaveAsync<T>(string path, T value)
    {
        Directory.CreateDirectory(DirectoryPath);
        var temporaryPath = path + ".tmp";
        await using (var stream = File.Create(temporaryPath)) await JsonSerializer.SerializeAsync(stream, value, Options);
        File.Move(temporaryPath, path, true);
    }

    private void Save<T>(string path, T value)
    {
        Directory.CreateDirectory(DirectoryPath);
        var temporaryPath = path + ".tmp";
        File.WriteAllText(temporaryPath, JsonSerializer.Serialize(value, Options));
        File.Move(temporaryPath, path, true);
    }
}
