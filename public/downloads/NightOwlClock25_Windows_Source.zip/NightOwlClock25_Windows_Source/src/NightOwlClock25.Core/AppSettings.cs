namespace NightOwlClock25.Core;

public sealed class AppSettings
{
    public const double DefaultWindowLeft = 100;
    public const double DefaultWindowTop = 100;
    public const double DefaultWindowWidth = 520;
    public const double DefaultWindowHeight = 780;
    public const string DefaultDigitalClockFontFamily = "Cascadia Mono,Consolas";
    public const double DefaultDigitalClockFontSize = 44;
    public const double MinimumDigitalClockFontSize = 40;
    public const double MaximumDigitalClockFontSize = 100;

    public int BoundaryHour { get; set; } = 5;
    public bool ShowsSeconds { get; set; }
    public bool AlwaysOnTop { get; set; }
    public bool LaunchAtLogin { get; set; }
    public string DigitalClockFontFamily { get; set; } = DefaultDigitalClockFontFamily;
    public double DigitalClockFontSize { get; set; } = DefaultDigitalClockFontSize;
    public double WindowLeft { get; set; } = DefaultWindowLeft;
    public double WindowTop { get; set; } = DefaultWindowTop;
    public double WindowWidth { get; set; } = DefaultWindowWidth;
    public double WindowHeight { get; set; } = DefaultWindowHeight;
    public bool IsMaximized { get; set; }
    public bool HasWindowPlacement { get; set; }

    /// <summary>JSONに書き込めないウィンドウ値を安全な既定値へ置換し、該当プロパティ名を返します。</summary>
    public IReadOnlyList<string> NormalizeWindowValues()
    {
        var invalid = new List<string>();
        WindowLeft = FiniteOrDefault(WindowLeft, DefaultWindowLeft, nameof(WindowLeft), invalid);
        WindowTop = FiniteOrDefault(WindowTop, DefaultWindowTop, nameof(WindowTop), invalid);
        WindowWidth = PositiveFiniteOrDefault(WindowWidth, DefaultWindowWidth, nameof(WindowWidth), invalid);
        WindowHeight = PositiveFiniteOrDefault(WindowHeight, DefaultWindowHeight, nameof(WindowHeight), invalid);
        return invalid;
    }

    public IReadOnlyList<string> NormalizeDisplayValues()
    {
        var invalid = new List<string>();
        if (string.IsNullOrWhiteSpace(DigitalClockFontFamily))
        {
            invalid.Add(nameof(DigitalClockFontFamily));
            DigitalClockFontFamily = DefaultDigitalClockFontFamily;
        }
        if (!double.IsFinite(DigitalClockFontSize) || DigitalClockFontSize < MinimumDigitalClockFontSize || DigitalClockFontSize > MaximumDigitalClockFontSize)
        {
            invalid.Add(nameof(DigitalClockFontSize));
            DigitalClockFontSize = DefaultDigitalClockFontSize;
        }
        return invalid;
    }

    private static double FiniteOrDefault(double value, double fallback, string propertyName, List<string> invalid)
    {
        if (double.IsFinite(value)) return value;
        invalid.Add(propertyName); return fallback;
    }

    private static double PositiveFiniteOrDefault(double value, double fallback, string propertyName, List<string> invalid)
    {
        if (double.IsFinite(value) && value > 0) return value;
        invalid.Add(propertyName); return fallback;
    }
}
