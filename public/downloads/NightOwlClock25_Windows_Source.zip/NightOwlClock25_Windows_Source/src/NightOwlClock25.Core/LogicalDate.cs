namespace NightOwlClock25.Core;

public readonly record struct LogicalDate(int Year, int Month, int Day)
{
    public DateOnly ToDateOnly()
    {
        try { return new DateOnly(Year, Month, Day); }
        catch (ArgumentOutOfRangeException exception)
        { throw new LogicalDateTimeException("有効な日付を指定してください。", exception); }
    }

    public static LogicalDate FromDateOnly(DateOnly value) => new(value.Year, value.Month, value.Day);
}
