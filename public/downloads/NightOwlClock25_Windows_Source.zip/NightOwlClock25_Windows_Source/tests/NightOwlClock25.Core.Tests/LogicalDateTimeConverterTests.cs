using NightOwlClock25.Core;

namespace NightOwlClock25.Core.Tests;

[TestClass]
public sealed class LogicalDateTimeConverterTests
{
    private static readonly TimeZoneInfo Tokyo = Find("Tokyo Standard Time", "Asia/Tokyo");
    private readonly LogicalDateTimeConverter _converter = new(Tokyo);

    [TestMethod]
    [DataRow(2027, 7, 8, 0, 0, 2027, 7, 7, 24, 0)]
    [DataRow(2027, 7, 8, 1, 25, 2027, 7, 7, 25, 25)]
    [DataRow(2027, 7, 8, 4, 59, 2027, 7, 7, 28, 59)]
    [DataRow(2027, 7, 8, 5, 0, 2027, 7, 8, 5, 0)]
    public void ActualToLogical_UsesFiveOClockBoundary(int y, int m, int d, int h, int min, int ly, int lm, int ld, int lh, int lmin)
    {
        var actual = new DateTimeOffset(y, m, d, h, min, 0, Tokyo.GetUtcOffset(new DateTime(y, m, d)));
        Assert.AreEqual(new LogicalDateTime(new LogicalDate(ly, lm, ld), lh, lmin), _converter.FromActual(actual, 5));
    }

    [TestMethod]
    [DataRow(2027, 1, 1, 25, 0, 2027, 1, 2, 1, 0)]
    [DataRow(2027, 1, 31, 25, 0, 2027, 2, 1, 1, 0)]
    [DataRow(2027, 2, 28, 25, 0, 2027, 3, 1, 1, 0)]
    [DataRow(2028, 2, 29, 25, 0, 2028, 3, 1, 1, 0)]
    [DataRow(2027, 12, 31, 25, 0, 2028, 1, 1, 1, 0)]
    public void LogicalToActual_HandlesMonthYearAndLeapTransitions(int y, int m, int d, int h, int min, int ay, int am, int ad, int ah, int amin)
    {
        var actual = _converter.ToActual(new LogicalDateTime(new LogicalDate(y, m, d), h, min));
        Assert.AreEqual(new DateTime(ay, am, ad, ah, amin, 0), actual.DateTime);
    }

    [TestMethod]
    public void DifferentTimeZone_RoundTripsExtendedHour()
    {
        var converter = new LogicalDateTimeConverter(Find("Eastern Standard Time", "America/New_York"));
        var logical = new LogicalDateTime(new LogicalDate(2027, 7, 7), 26, 30);
        Assert.AreEqual(logical, converter.FromActual(converter.ToActual(logical), 5));
    }

    [TestMethod]
    public void InvalidCivilDate_IsRejected() => Assert.ThrowsExactly<LogicalDateTimeException>(() => _converter.ToActual(new LogicalDateTime(new LogicalDate(2027, 2, 30), 25, 0)));

    [TestMethod]
    public void InvalidBoundary_IsRejected() => Assert.ThrowsExactly<ArgumentOutOfRangeException>(() => _converter.FromActual(DateTimeOffset.Now, 13));

    private static TimeZoneInfo Find(string windows, string iana)
    {
        try { return TimeZoneInfo.FindSystemTimeZoneById(windows); }
        catch (TimeZoneNotFoundException) { return TimeZoneInfo.FindSystemTimeZoneById(iana); }
    }
}
