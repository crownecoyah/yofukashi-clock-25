using System.Text.Json;
using NightOwlClock25.Core;

namespace NightOwlClock25.Core.Tests;

[TestClass]
public sealed class AppSettingsPersistenceTests
{
    private string _directory = null!;
    private JsonFileStore _store = null!;

    [TestInitialize]
    public void Initialize()
    {
        _directory = Path.Combine(Path.GetTempPath(), "NightOwlClock25.Tests", Guid.NewGuid().ToString("N"));
        _store = new JsonFileStore(_directory);
    }

    [TestCleanup]
    public void Cleanup()
    {
        if (Directory.Exists(_directory)) Directory.Delete(_directory, recursive: true);
    }

    [TestMethod]
    public void Defaults_AreFiniteEvenBeforeWindowPlacementExists()
    {
        var settings = new AppSettings();
        Assert.IsFalse(settings.HasWindowPlacement);
        Assert.IsTrue(double.IsFinite(settings.WindowLeft));
        Assert.IsTrue(double.IsFinite(settings.WindowTop));
        Assert.IsTrue(double.IsFinite(settings.WindowWidth));
        Assert.IsTrue(double.IsFinite(settings.WindowHeight));
    }

    [TestMethod]
    public void NormalizeWindowValues_ReportsEveryInvalidProperty()
    {
        var settings = new AppSettings
        {
            WindowLeft = double.NaN,
            WindowTop = double.PositiveInfinity,
            WindowWidth = double.NegativeInfinity,
            WindowHeight = double.NaN
        };
        var invalid = settings.NormalizeWindowValues();
        CollectionAssert.AreEquivalent(new[] { "WindowLeft", "WindowTop", "WindowWidth", "WindowHeight" }, invalid.ToArray());
        Assert.IsTrue(new[] { settings.WindowLeft, settings.WindowTop, settings.WindowWidth, settings.WindowHeight }.All(double.IsFinite));
    }

    [TestMethod]
    public async Task FirstLaunch_DefaultFive_CanChangeToFourAndReload()
    {
        var settings = new AppSettings();
        Assert.AreEqual(5, settings.BoundaryHour);
        settings.BoundaryHour = 4;
        await _store.SaveSettingsAsync(settings);
        Assert.AreEqual(4, (await _store.LoadSettingsAsync()).BoundaryHour);
    }

    [TestMethod]
    public void SynchronousSave_CompletesWithoutDependingOnASynchronizationContext()
    {
        var previous = SynchronizationContext.Current;
        try
        {
            SynchronizationContext.SetSynchronizationContext(new NonPumpingSynchronizationContext());
            _store.SaveSettings(new AppSettings { BoundaryHour = 4 });
            var compatibilityTask = _store.SaveSettingsAsync(new AppSettings { BoundaryHour = 5 });
            Assert.IsTrue(compatibilityTask.IsCompletedSuccessfully);
        }
        finally { SynchronizationContext.SetSynchronizationContext(previous); }
    }

    [TestMethod]
    public async Task BoundaryHours_ZeroThroughTwelve_CanBeSavedRepeatedlyAndReloaded()
    {
        var settings = new AppSettings();
        foreach (var boundary in Enumerable.Range(0, 13).Concat(Enumerable.Range(0, 13)))
        {
            settings.BoundaryHour = boundary;
            await _store.SaveSettingsAsync(settings);
            var loaded = await _store.LoadSettingsAsync();
            Assert.AreEqual(boundary, loaded.BoundaryHour);
        }
    }

    [TestMethod]
    public async Task InvalidWindowValues_DoNotBlockUnrelatedSettingSave_AndJsonHasNoNamedNumbers()
    {
        var settings = new AppSettings
        {
            BoundaryHour = 4,
            WindowLeft = double.NaN,
            WindowTop = double.PositiveInfinity,
            WindowWidth = double.NaN,
            WindowHeight = double.NegativeInfinity
        };
        await _store.SaveSettingsAsync(settings);

        var json = await File.ReadAllTextAsync(_store.SettingsPath);
        Assert.IsFalse(json.Contains("NaN", StringComparison.Ordinal));
        Assert.IsFalse(json.Contains("Infinity", StringComparison.Ordinal));
        using var document = JsonDocument.Parse(json);
        foreach (var name in new[] { "WindowLeft", "WindowTop", "WindowWidth", "WindowHeight" })
            Assert.AreEqual(JsonValueKind.Number, document.RootElement.GetProperty(name).ValueKind, name);

        var loaded = await _store.LoadSettingsAsync();
        Assert.AreEqual(4, loaded.BoundaryHour);
        Assert.IsTrue(new[] { loaded.WindowLeft, loaded.WindowTop, loaded.WindowWidth, loaded.WindowHeight }.All(double.IsFinite));
    }

    [TestMethod]
    public async Task ResizedAndMaximizedPlacement_RoundTrips()
    {
        var settings = new AppSettings { WindowLeft = 210, WindowTop = 90, WindowWidth = 860, WindowHeight = 920, IsMaximized = true, HasWindowPlacement = true };
        await _store.SaveSettingsAsync(settings);
        var loaded = await _store.LoadSettingsAsync();
        Assert.AreEqual(860, loaded.WindowWidth); Assert.AreEqual(920, loaded.WindowHeight);
        Assert.IsTrue(loaded.IsMaximized); Assert.IsTrue(loaded.HasWindowPlacement);
    }

    [TestMethod]
    public async Task DigitalClockFontAndSize_RoundTrip()
    {
        var settings = new AppSettings { DigitalClockFontFamily = "Consolas", DigitalClockFontSize = 72 };
        await _store.SaveSettingsAsync(settings);
        var loaded = await _store.LoadSettingsAsync();
        Assert.AreEqual("Consolas", loaded.DigitalClockFontFamily);
        Assert.AreEqual(72, loaded.DigitalClockFontSize);
    }

    [TestMethod]
    [DataRow(double.NaN)]
    [DataRow(double.PositiveInfinity)]
    [DataRow(39)]
    [DataRow(101)]
    public async Task InvalidDigitalClockSize_FallsBackWithoutBreakingJson(double invalidSize)
    {
        var settings = new AppSettings { DigitalClockFontFamily = "", DigitalClockFontSize = invalidSize };
        await _store.SaveSettingsAsync(settings);
        var json = await File.ReadAllTextAsync(_store.SettingsPath);
        Assert.IsFalse(json.Contains("NaN", StringComparison.Ordinal));
        Assert.IsFalse(json.Contains("Infinity", StringComparison.Ordinal));
        var loaded = await _store.LoadSettingsAsync();
        Assert.AreEqual(AppSettings.DefaultDigitalClockFontFamily, loaded.DigitalClockFontFamily);
        Assert.AreEqual(AppSettings.DefaultDigitalClockFontSize, loaded.DigitalClockFontSize);
    }

    private sealed class NonPumpingSynchronizationContext : SynchronizationContext
    {
        public override void Post(SendOrPostCallback callback, object? state) { }
    }
}
